﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define e = Character("Eileen")
define john = Character("John")
define snorky = Character ("Snorky")
define faldi = Character("Faldi")
define felis = Character("Felis")


# The game starts here.

label start:

    # Show a background. This uses a placeholder by default, but you can
    # add a file (named either "bg room.png" or "bg room.jpg") to the
    # images directory to show it.

    scene apart-night-new

    # This shows a character sprite. A placeholder is used, but you can
    # replace it by adding a file named "eileen happy.png" to the images
    # directory.
    show m-j with fade
    john "hellow"
    show john-stylized with  dissolve
    hide m-j

    # These display lines of dialogue.

    # e "You've created a new Ren'Py game."

    john "hellow 2"

    show john at left with moveoutleft
    show snorky at right
    with dissolve

    snorky "Hellow John"

    # This ends the game.

    return
