define voicechar ="audio/Voice/Person 2.ogg"
init python:
    def type_sound(event, interact=True, **kwargs):
        if not interact:
            return

        if event == "show_done":
            renpy.sound.play(voicechar,loop = True)
        elif event == "slow_done":
            renpy.sound.stop()

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define faldi = Character("Faldi",callback=type_sound,color="#336FF2")
define felis = Character("Felis",callback=type_sound,color="#ff69b4")

define john = Character("John",callback=type_sound,color="#F23333")
define snorky = Character ("Snorky",callback=type_sound,color="#F2C933")

define mj = Character("????",callback=type_sound)
define ms = Character("??????",callback=type_sound)

define n = Character("",callback=type_sound)