﻿# The script of the game goes in this file.

# Declare Characters inside se.rpy
        

image johncard = "images/john-card.jpg"
image jungkook_movie = Movie(play="video/jungkook.webm")

# The game starts here.

label start:
    $ renpy.music.set_volume(0.3, delay=0, channel="music")
    play music "BGM/apart-days.mp3"
    scene apart-day
    show faldi
    # show john-px at left
    # show snorky-px at right
   
    faldi "beneran harus pergi beb? dingin nih klo sendirian"

    felis "...."
    #call snorkypresent
    felis "Yoi entah kenapa dokter gigi nya di pindah ke hari ini, mana ngantri banget lagi"

    felis "jagain apart ya beb"
    
    faldi "yahh ok deh"
    scene black with fade

    "cipika cipiki and pelukan"

    scene apart-day
    show faldi 
    with fade
    faldi "hmm sepi"

    faldi "well saatnya rewatch little sheldon untuk ke 20 kali nya"
    show mj at right
    mj "bosen gk sih bro"
    play music "BGM/encounter.mp3"
    faldi "Siapa tuh yg ngomong, halo?"

    mj "Bosen ih rewatch itu mulu"

    show john-px at right

    faldi "JOHN!?"

    john "Breaking Bad aja"

    faldi "fym Breaking Bad, kamu bisa ngomong?"

    john "Harusnya sih rahasia, tpi gk tahan nonton Sheldon terus"

    ms "bener john, bosen banget"

    show ms at left

    faldi "siapa lgi tuh-"

    show snorky-px at left

    snorky "halo~"

    faldi "AGHHHHHHH"

    scene black with fade

    "'BEUGH' suara benturan dri kepala Faldi dengan lantai"
    ".........."
    "4 jam kemudian..."

    show apart-night with pixellate
    show faldi at center
    faldi "ghhhh, wtf happen. Mimpi nya aneh banget"
    faldi "..."
    faldi "masa john and snorky bisa.."
    show faldi at left with move
    show snorky-px at right with move
   

    snorky "gk mimpi ko~"

    faldi "Astagfir *Baca yasin"
    show john-px at center with dissolve
    john "sok suci juga nih anak"
    snorky "hahahahah"
    john "ngomong-ngomong, Felis kemana Fal? Sepi banget nih, jadi dingin"
    faldi " *Sigh harusnya sih udh balik, cuma kayaknya penuh dokter gigi nya"
    play music "BGM/apart-night.mp3"
    john "btw udah beli kado buat felis?"

    snorky "iya bentar lagi kan felis ultah"

    faldi "hmm jujur bingung nih. Udah beli satu kado sih, tpi terlalu practical takutnya gk kerasa sentiment"

    john "coba liat kado nya"

    faldi "jangan dong, nanti spoiler"

    snorky "yea dumbass john ~"
    john "hmm"
    faldi "hmm"
    snorky "hmm~"
    "..."
    snorky "kalo gitu, gimana klo Aku and John bikin present yg sentimental buat Felis. Biar bisa di inget terus sama Felis"

    faldi "gass, pinter nih snorky unlike john"

    john "anjing"
    scene black
    with fade

    "Mereka pun sibuk masing-masing menyiapkan hadiah untuk Felis"
    show apart-night with pixellate
    show faldi 
    faldi "Gimana guys, udah pada selesai kah?"
    show faldi at left with move
    show john-px with dissolve
    john "Yang punya aku keren banget sih"
    show snorky-px at right with dissolve
    snorky "Lebih keren aku sih, mahal banget lgi biaya bikin nya"
    john "Mahal? wdym mahal"
    faldi "Ok langsung kita showcase aja deh"

    john "Aku mau pertama!"

    john "Aku bikin ini guys"

    call johncard
    play music "BGM/john-prize.mp3"
    faldi "what the..."

    snorky "i-ini..."
   
    john "Gimana guys, bagus kan? kerasa banget kan sentiment nya"

    faldi "ini mah malah kayak in memoriam bjir"

    snorky "m-mudah-mudahan suka deh dia (goblok banget John)"
    john "Mudah-mudahan? Pasti suka lah dia"
    faldi "I-itu bukan kayak kartu ucapan ultah tahun John..."
    snorky "Iya itu lebih ke.. Hmmm gimana ya cara ngomong nya"
    john "TAPI ITU AKU BIKIN NYA DENGAN SEPENUH HATI!"
    john "Cape tau..."
    snorky "O-ok deh.."
    hide johncard with dissolve
    play music "BGM/apart-night.mp3"
    faldi "Okay, next Snorky!"
    snorky "Siap-siap guys, sorry ya kalo kado kalian jadi terlihat jelek dibanding kado dari aku"
    john "Grr"
    faldi "Iya deh (jadi penasaran nih)"
    stop music fadeout 0.5
    snorky "Siap-siap guys"
    snorky "3..2..1..Go!"

    call snorkypresent
   
    snorky "BOOM, jongkook itself guys"
    play sound "BGM/fah.ogg"
    pause 1.0
    play music "BGM/apart-night.mp3"
    john "Woahh, itu jongkook beneran?"
    snorky "heheh tentu lah, tapi mahal bayar nya. Biasa jadwal nya lagi penuh, tapi ini adalah kado yang pas untuk seorang Army"
    faldi "Totally bukan prompt hasil AI..."
    snorky "Pffft, AI? ngomong apa sih kamu"
    faldi "(Kacau bener ini dua, harapan terakhir nya ada di hadiah yang aku beli)"
   
    hide john-px with dissolve
    hide snorky-px with dissolve
    show faldi at center with move
    faldi "WOIII!"
    faldi "oi! IRL Faldi"
    faldi "Yes iya lu"
    faldi "Kasih kadonya yang kamu beli kemaren"
    faldi "iya sekarang, dua hadiah dari John sama Snorky gk layak soalnya"

    faldi "Ok sekarang coba pilih hadiah dari siapa yang paling bagus beb"

    show snorky-px at right with dissolve
    show john-px at left with dissolve

    menu:
        "Pilih hadiah terbaik:"

        "Faldi":
            jump faldiwon

        "Snorky":
            jump snorkywon

        "John":
            jump johnwon
    return

label johncard:
    show johncard:
        xalign 0.5
        yalign 0.08
        zoom 0.9
        alpha 0.0
        yoffset 200
        ease 0.5 alpha 1.0 yoffset 0
    return

label snorkypresent:
    

    show jungkook_movie:
        xalign 0.5
        yalign 0.08
        zoom 0.9
        alpha 0.0
        yoffset 200
        ease 0.5 alpha 1.0 yoffset 0
    pause

    hide jungkook_movie with dissolve
    
    return


label faldiwon:
    play music "BGM/winner.mp3"
    faldi "Yessir"
    faldi "Aneh sih kalo Felis lebih suka kado-kado jelek itu"
    faldi "hahah"
    john "grrr"
    snorky "masa lebih keren dari hadiah aku~ hiks hiks"
    snorky "p-pedahal aku habis 5jt lebih buat nyuruh jongkook"
    play music "BGM/encounter.mp3"
    faldi "..."
    john "GRRRR"
    faldi "j-john tenang, chill out bro"
    snorky "GRRR I'm seeing red right now"
    faldi "..."
    faldi "guys?"

    scene black with fade
    "Snorky dan John dengan penuh amarah loncat ke muka Faldi, and goes ham..."
    "RIP Faldi Sugih Bimazahran"
    "Makasih udah main cayang, lopyu <3"

    return

label snorkywon:
    play music "BGM/winner.mp3"
    snorky "Yippie!"
    snorky "Worth it nih bayar 5jt lebih"
    john "5 JUTA!!??"
    snorky "yap, tapi include paket nelp juga sih"
    faldi "..."
    john "Coba telp"
    "....."
    snorky "kok gak di angkat angkat ya..."
    faldi "coba liat nomornya"
    faldi "alamak ini nomornya dari india snorky"
    snorky "....."

    scene black with fade
    "RIP Dompet Snorky"
    "Makasih udah main cayang, lopyu <3"

    return

label johnwon:
    play music "BGM/winner.mp3"
    john "Hahahah sudah kuduga, memang hadiahku yg paling bagus"
    snorky "....."
    faldi "....."
    faldi "kok bisa dia milih hadiah john sih"
    snorky "apa jangan-jangan felis..."
    faldi "Beb lu gk kenapa napa kan? lgi gk stress kan?"
    snorky "klo ada apa-apa bilang ya sama kita"
    john "kok tiba-tiba pada khawatir sih"
    john "gk ngerti deh"
    faldi "........."
    snorky "........."

    scene black with fade
    "RIP Otak logika nya John"

    "Makasih udah main cayang, lopyu <3"

    return
